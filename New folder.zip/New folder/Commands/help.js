module.exports = {
    name: 'help',
    description: "hi",
    execute(message, args){
        message.channel.send('Commands: Help, RickRoll, info, leong, image, will, zayne, yoo, spaget, chair-man, update, status, insult.');
    }
}
