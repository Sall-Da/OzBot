const Discord = require('discord.js');
const {
    Client, 
    Attachment
} = require('discord.js');
const bot = new Client();
const token = 'NzA5NjI3Mjk1MDczMzA0Njc2.Xro5wQ.2x2RG5pbd25Fr6EguHDmOwqqw7g';
const PREFIX = '>';
var version = '1.2.2'
var update = 'The image command is down at the moment.'
const cheerio = require('cheerio');
const request = require('request');

const fs = require('fs');
bot.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for (const file of commandFiles){
    const command = require(`./commands/${file}`);
    bot.commands.set(command.name, command);
}

bot.on('ready', () =>{
    console.log('This Bot is online!' + version);
    bot.user.setActivity('Living on a prayer', { type: 'WATCHING'});

})

bot.on('message', message =>{

    let args = message.content.substring(PREFIX.length).split(" ");

    if (msg.content.startsWith(PREFIX + 'insult')) {

        var array = ['a','b','c']
                      
        msg.channel.send(array[random])
            }


    switch(args[0]) {
        case "help":
            bot.commands.get('help').execute(message, args);
            break;
        case 'RickRoll':
            message.channel.send('https://www.youtube.com/watch?v=oHg5SJYRHA0')
            break;
        case 'info':
            if(args[1] === 'version'){
                message.channel.send('Creator- OzTomato Version ' + version);
            }else{
                message.channel.send('Invalid command')
            }
            break;
        case 'leong':
            message.channel.send('I steal dog, I skin dog, I cook dog, I eat dog')
            break;
        case 'image':
            image(message);
        case 'update':
            message.channel.send(update)
            break;
        case 'chair-man':
            message.channel.send('https://media.discordapp.net/attachments/692893871952363520/709676086119759902/20200512_175839.png?width=224&height=398')
            break;
        case 'spaget':
            message.channel.send('https://media.discordapp.net/attachments/596242765185286185/638158813870161920/20191027_105606.png')
            break;
        case 'will':
            message.channel.send('sexy willie')
            break;
        case 'yoo':
            message.channel.send(';p crank that')
            break;
        case 'status':
            message.channel.send(update)
            break;
        case 'zayne':
            message.channel.send('Bow to the God')
            break;
            
    }
    if (message.content === "chair-man"){
        message.reply('https://media.discordapp.net/attachments/692893871952363520/709676086119759902/20200512_175839.png?width=224&height=398')
    }
});
function image(message){

    var options = {
        url: "https://www.google.com.au/search?hl=en&tbm=isch&source=hp&biw=978&bih=539&ei=EEG7XtLPNIuO4-EP_eyt-A8&q=cursed+images&oq=cursed+&gs_lcp=CgNpbWcQARgAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIAFDHB1jzE2DuIGgAcAB4AIAB4QKIAZULkgEHMC40LjIuMZgBAKABAaoBC2d3cy13aXotaW1nsAEA&sclient=img",
        method: "GET",
        headers: {
            "Accept": "text/html",
            "User-Agent": "Chrome"
        }
    };

    request(options,function(error, response, responseBody) {
        if (error) {
            return;
        }

        $ = cheerio.load(responseBody);

        var links = $(".image a.link");

        var urls = new Array(links.length).fill(0).map((v, i) => links.eq(i).attr("herf"));

        console.log(urls);

        if (!urls.length) {
            return;
        }
        //send result
        message.channel.send( urls[Math.floor(Math.random() * urls.length)]);
    });
}


bot.login(token);